<?php
/**
 * WR-Panel
 *
 * @version 1.0.9
 * @author Miller P. Magalhães
 * @link http://www.millerdev.com.br
 *
 */
?>
<div id="mws-error-container">
  <h1 id="mws-error-code">Error <span>404</span></h1>
  <p id="mws-error-message">Desculpe-nos, não achamos o que procurava.</p>
</div>