<?php
/**
 * WR-Panel
 *
 * @version 1.0.9
 * @author Miller P. Magalhães
 * @link http://www.millerdev.com.br
 *
 */
?>
<div class="mws-panel grid_8 mws-collapsible">
  <!-- Panel Header -->
  <div class="mws-panel-header">
    <span>
      Downloads - Todos
    </span>
    <div class="mws-collapse-button mws-inset"><span></span>
    </div>
  </div>
  <!-- Panel Body -->
  <div class="mws-panel-body">

  </div>
</div>