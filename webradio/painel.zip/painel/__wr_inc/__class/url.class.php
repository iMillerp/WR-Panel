<?php

/**
 * WR-Panel
 *
 * @version 1.0.9
 * @author Miller P. Magalhães
 * @link http://www.millerdev.com.br
 *
 */
class url {

  var $GetString;
  var $GetLocal;

  function writepage() {
    if (isset($this->GetString) == true) {
      if (file_exists($this->GetLocal . "/" . $this->GetString . ".php")) {
        require_once($this->GetLocal . "/" . $this->GetString . ".php" );
        exit();
      } else {
        require_once("__paginas/error.php");
        exit();
      }
    }
  }

}

?>
