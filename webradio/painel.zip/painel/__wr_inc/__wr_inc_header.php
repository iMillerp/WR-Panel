<?php
/**
 * WR-Panel
 *
 * @version 1.0.9
 * @author Miller P. Magalhães
 * @link http://www.millerdev.com.br
 *
 */
?>
<head>
  <title>WebRadio - WR-Panel v1.0</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
