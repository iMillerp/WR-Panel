<?php
// Incluimos a classe
require_once("__wr_inc/__class/__wr_inc_class_login.class.php");

// Instanciamos a classe
$login = new Login();

/*
Realizamos o logout através da função logout(),
que aceita como parâmetro facultativo o local para onde o usuário
será redirecionado.
*/
$login->logout("index.php");
?>